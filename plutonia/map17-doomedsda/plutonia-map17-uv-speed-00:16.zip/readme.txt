Doomed Speed Demos Archive
http://doomedsda.us/

iwad:      plutonia.wad
Pwad name: Plutonia Experiment
Maps:      17
Skill:     4
Category:  Speed
Exe:       prboom+ (Version 2.5.1.3)

Time:      0:16

Author:   Justin Ethier 
Email:    justin.ethier@gmail.com
HP:       https://plus.google.com/u/0/b/113743049742496559893/113743049742496559893

Comments: Looks to be a new (non-TAS) record for this map.

